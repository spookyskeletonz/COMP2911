
/**
 * A cardinal direction.
 *
 */
public enum Direction {
	UP,
	RIGHT,
	DOWN,
	LEFT
}
